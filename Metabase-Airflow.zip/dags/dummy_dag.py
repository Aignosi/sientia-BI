import csv
import imp
import logging
import os
from datetime import datetime, timedelta
from io import BytesIO
from xmlrpc.client import FastParser

import pandas as pd
import psycopg2 as pg
from airflow import DAG
from airflow.decorators import dag, task, task_group
from airflow.operators.dummy import DummyOperator
from airflow.operators.email_operator import EmailOperator
from airflow.providers.amazon.aws.sensors.s3 import S3KeySensor
from minio import Minio
from minio.commonconfig import CopySource

#########################
# Variables Environment #
#########################

#ENDPOINT_S3 = os.getenv('ENDPOINT_S3', 'host.docker.internal:9000')
#ACCESS_KEY_S3 = os.getenv('ACCESS_KEY_S3', 'minioadmin')
#SECRET_KEY_s3 = os.getenv('SECRET_KEY_s3', 'minioadmin')
#
#LANDING_ZONE = os.getenv('RAW_BUCKET', 'landing')
#PROCESSING_ZONE = os.getenv('PROCESSING_BUCKET', 'processing')
#CURATED_ZONE = os.getenv('PROCESSING_BUCKET', 'curated')


S3_CONNECTION = 'minio_connection'

ENDPOINT_S3 = "host.docker.internal:9000"
ACCESS_KEY_S3 = "minioadmin"
SECRET_KEY_s3 = "minioadmin"

LANDING_ZONE = "landing"
PROCESSING_ZONE = "processing"
CURATED_ZONE = "curated"

# DAG default args
default_args = {
    'owner': 'Data Engineering',
    'retries': 0
}


@dag(
    #schedule_interval=timedelta(minutes=0, seconds=30), 
    schedule_interval='@once', 
    start_date=datetime(2022, 8, 1),
    catchup=False
)
def etl():

    MINIO_CLIENT = Minio(
        endpoint="host.docker.internal:9000",
        access_key='minioadmin',
        secret_key='minioadmin',
        secure=False
    )

    @task
    def list_csv_files_in_raw(minio_client):

        logging.info("Check all csv files in bucket: %s", LANDING_ZONE)

        csv_files = []

        objects_minio = minio_client.list_objects(LANDING_ZONE)

        for obj in objects_minio:
            if obj.object_name.endswith('.csv'):
                csv_files.append(obj.object_name)

        logging.debug("All csv files in bucket raw: ", csv_files)

        return csv_files


    @task
    def copy_csv_to_staging(minio_client, csv_file):

        print("Copying csv file to staging: ", csv_file)

        #minio_client = Minio(
        #    endpoint="host.docker.internal:9000",
        #    access_key='minioadmin',
        #    secret_key='minioadmin',
        #    secure=False
        #)

        result = minio_client.copy_object(
            PROCESSING_ZONE,
            csv_file,
            CopySource(LANDING_ZONE, csv_file),
        )

        print(result.object_name, result.version_id)

        return csv_file


    @task
    def delete_csv_from_raw(minio_client, csv_file):

        print("Deleting csv from raw: ", csv_file)
        
        #minio_client.remove_object(
        #    LANDING_ZONE,
        #    csv_file,
        #)

        print("Deleted csv from raw: ", csv_file)

    
    @task
    def process_csv_file(minio_client, csv_file):

        obj = minio_client.get_object(
            PROCESSING_ZONE,
            csv_file,
        )

        dataframe = pd.read_csv(obj)

        ### Processing data

        csv = dataframe.to_csv(header=True, index=False).encode('utf-8')
        
        
        minio_client.put_object(
            bucket_name=CURATED_ZONE,
            object_name=csv_file,
            data=BytesIO(csv),
            length=len(csv),
            content_type='application/csv'
        )

        print("CSV: ", csv_file)

        return csv_file


    @task
    def save_data_to_database(minio_client, csv_file):

        connection = None
        cursor = None

        print("Dataframe")

        obj = minio_client.get_object(
            CURATED_ZONE,
            csv_file,
        )

        dataframe = pd.read_csv(obj)
        dataframe.set_index('Timestamp', inplace=True)

        try:
            connection = pg.connect(
                user='admin',
                password='quest',
                host='host.docker.internal',
                port='8812',
                database='qdb'
            )

            cursor = connection.cursor()

            for tag in dataframe.columns:

                cursor.execute(
                    f'''
                    CREATE TABLE IF NOT EXISTS {tag} (
                    timestamp TIMESTAMP, value DOUBLE)
                    timestamp(timestamp) partition by DAY
                    '''
                )

                for time, value in zip(dataframe.index, dataframe[tag]):

                    time = datetime.strptime(time, "%Y-%m-%d %H:%M:%S").isoformat()

                    query = f"""INSERT INTO {tag} VALUES ('{time}', {value});"""
                    cursor.execute(query)

                connection.commit()


        finally:
            if cursor:
                cursor.close()
            if connection:
                connection.close()
            print('Postgres connection is closed.')

        pass


    @task
    def print_all_files(csv):

        print("BRENO")
        print(len(csv))
        for file in csv:
            print("FIle")
            print(file)
        print("A")
    
        return True



    csv_files_in_raw = list_csv_files_in_raw(minio_client=MINIO_CLIENT)
    copy_to_staging = copy_csv_to_staging.partial(minio_client=MINIO_CLIENT).expand(csv_file=csv_files_in_raw)
    delete_csv_from_raw = delete_csv_from_raw.partial(minio_client=MINIO_CLIENT).expand(csv_file=copy_to_staging)
    process_csv_file = process_csv_file.partial(minio_client=MINIO_CLIENT).expand(csv_file=copy_to_staging)
    #TAG = process_csv_file["tag"]
    #DATAFRAME = process_csv_file["dataframe"]
    b = print_all_files(csv=process_csv_file)    
    save_data_to_database = save_data_to_database.partial(minio_client=MINIO_CLIENT).expand(csv_file=process_csv_file)
    #save_data_to_database.expand(tag=TAG, dataframe=DATAFRAME)
    #save_data_to_database.partial(tag='A', dataframe=process_parquet_file)
    #save_data_to_database >> email_notification


dag = etl()
