import csv
import imp
import logging
import os
from datetime import datetime, timedelta
from io import BytesIO
from xmlrpc.client import FastParser

import pandas as pd
import psycopg2 as pg
from airflow import DAG
from airflow.decorators import dag, task, task_group
from airflow.operators.dummy import DummyOperator
from airflow.operators.email_operator import EmailOperator
from airflow.providers.amazon.aws.sensors.s3 import S3KeySensor
from minio import Minio
from minio.commonconfig import CopySource
from sqlalchemy import (Column, Float, Integer, MetaData, String, Table,
                        create_engine)

#########################
# Variables Environment #
#########################

ENDPOINT_S3 = "host.docker.internal:9000"
ACCESS_KEY_S3 = "minioadmin"
SECRET_KEY_s3 = "minioadmin"

LANDING_ZONE = "landing"
CURATED_ZONE = "curated"

# DAG default args
default_args = {
    'owner': 'Data Engineering',
    'retries': 0
}


@dag(
    #schedule_interval=timedelta(minutes=0, seconds=30), 
    schedule_interval='@once', 
    start_date=datetime(2022, 8, 1),
    catchup=False
)
def etl():

    MINIO_CLIENT = Minio(
        endpoint="host.docker.internal:9000",
        access_key='minioadmin',
        secret_key='minioadmin',
        secure=False
    )

    @task
    def list_csv_files_in_landing(minio_client):

        logging.info("Check all csv files in bucket: %s", LANDING_ZONE)

        csv_files = []

        objects_minio = minio_client.list_objects(LANDING_ZONE)

        for obj in objects_minio:
            if obj.object_name.endswith('.csv'):
                csv_files.append(obj.object_name)

        logging.debug("All csv files in bucket raw: ", csv_files)

        return csv_files


    @task
    def copy_csv_to_curated(minio_client, csv_file):

        print("Copying csv file to curated: ", csv_file)

        result = minio_client.copy_object(
            CURATED_ZONE,
            csv_file,
            CopySource(LANDING_ZONE, csv_file),
        )

        print(result.object_name, result.version_id)

        return csv_file


    @task
    def delete_csv_from_landing(minio_client, csv_file):

        print("Deleting csv from landing: ", csv_file)
        
        minio_client.remove_object(
            LANDING_ZONE,
            csv_file,
        )

        print("Deleted csv from landing: ", csv_file)


    @task
    def save_data_to_database(minio_client, csv_file):

        engine = create_engine('postgresql://admin:admin@host.docker.internal:5433/metabase')

        if not engine.has_table(engine, 'Iris'):  # If table don't exist, Create.
            
            metadata = MetaData(engine)

            Table('Iris', metadata,
                Column('Id', Integer, primary_key=True, nullable=False), 
                Column('SepalLengthCm', Float, nullable=False),
                Column('SepalWidthCm', Float, nullable=False),
                Column('PetalLengthCm', Float, nullable=False), 
                Column('PetalWidthCm', Float, nullable=False),
                Column('Species', String, nullable=False)
            )

            metadata.create_all()

        else:
            print("Não existe a tabela Iris")

        obj = minio_client.get_object(
            CURATED_ZONE,
            csv_file,
        )

        dataframe = pd.read_csv(obj)

        dataframe.to_sql('Iris', engine, if_exists='append', index=False)
        print("Dados inseridos")

        pass


    csv_files_in_landing = list_csv_files_in_landing(minio_client=MINIO_CLIENT)
    copy_to_curated = copy_csv_to_curated.partial(minio_client=MINIO_CLIENT).expand(csv_file=csv_files_in_landing)
    delete_csv_from_landing = delete_csv_from_landing.partial(minio_client=MINIO_CLIENT).expand(csv_file=copy_to_curated)
    save_data_to_database = save_data_to_database.partial(minio_client=MINIO_CLIENT).expand(csv_file=copy_to_curated)


dag = etl()
